## Architecture
The system architecture is a client-server architecture with a monolithic backend and a separate frontend. The backend is built using Node.js, Express.js, and MongoDB, while the frontend is built using React.

### Major Layers / Tiers
The system consists of the following major layers:

1. **Presentation Layer**: The frontend, built using React, handles user interaction and rendering of the user interface.
2. **Application Layer**: The backend, built using Node.js and Express.js, handles business logic and API requests.
3. **Data Access Layer**: The MongoDB database, accessed using Mongoose, stores and retrieves data.

### Data Flow
Data flows from the Presentation Layer to the Application Layer, which then interacts with the Data Access Layer to retrieve or store data.

### Key Integration Points
The system integrates with the following external APIs:

* `/api/users/${userId}`
* `/api/auth/me`
* `/api/users`
* `/api/tasks/${taskId}`
* `/api/tasks`
* `/api/tasks/${id}`

The system also uses the following internal APIs:

* `../server/server` (exports the Express.js server)
* `../models/User` (exports the User model)
* `../models/Task` (exports the Task model)
* `../middleware/authMiddleware` (exports the authentication middleware)

### Notable Design Patterns
The system uses the following design patterns:

* **Repository Pattern**: The `../models/User` and `../models/Task` modules export the User and Task models, which encapsulate data access and manipulation.
* **Dependency Injection**: The `../middleware/authMiddleware` module exports the authentication middleware, which is injected into the Express.js server.
* **Service-Oriented Architecture**: The system is organized into separate services, each responsible for a specific domain logic (e.g., authentication, tasks, users).

### Code Organization
The system is organized into the following directories:

* `api`: Exports the Vercel serverless application entry point.
* `server`: Contains the Express.js server, middleware, and routes.
* `src`: Contains the React application code.
* `models`: Contains the Mongoose models for the User and Task collections.
* `middleware`: Contains the authentication middleware.

### Trade-Offs
The system makes the following trade-offs:

* **Monolithic Backend**: The backend is a single, monolithic application, which simplifies development and deployment but may make it harder to scale and maintain.
* **Separate Frontend**: The frontend is a separate application, which allows for more flexibility and scalability but may require additional infrastructure and maintenance.

Overall, the system architecture is designed to be scalable, maintainable, and easy to develop, while also meeting the requirements of the application.