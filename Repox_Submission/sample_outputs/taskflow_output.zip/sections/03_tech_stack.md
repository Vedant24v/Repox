# Tech Stack

## Backend Runtime
The backend runtime is built using Node.js, which is the runtime environment for JavaScript on the server-side.

* **What it is**: Node.js is a JavaScript runtime built on Chrome's V8 JavaScript engine that allows developers to run JavaScript on the server-side.
* **Why this project uses it**: The project uses Node.js as the runtime environment for the server-side logic, allowing for efficient and scalable execution of JavaScript code.
* **Where you'll see it**: The `server/server.js` file sets up the Express.js server, which is built on top of Node.js.
* **Depends on**: Express.js, MongoDB (via Mongoose), and other dependencies listed in the `package.json` file.

## Backend Framework
The backend framework used in this project is Express.js, a popular Node.js web framework for building web applications.

* **What it is**: Express.js is a minimal and flexible Node.js web application framework that provides a robust set of features for building web applications.
* **Why this project uses it**: The project uses Express.js as the backend framework to handle HTTP requests and responses, and to define routes for API endpoints.
* **Where you'll see it**: The `server/server.js` file sets up the Express.js server, and the `server/routes/*` files define routes for API endpoints using Express.js.
* **Depends on**: Node.js, Mongoose, and other dependencies listed in the `package.json` file.

## Database
The database used in this project is MongoDB, a NoSQL document-based database.

* **What it is**: MongoDB is a NoSQL document-based database that stores data in JSON-like documents.
* **Why this project uses it**: The project uses MongoDB as the database to store data for users, tasks, and other entities.
* **Where you'll see it**: The `server/server.js` file connects to the MongoDB database using Mongoose, and the `server/models/*` files define Mongoose models for interacting with the database.
* **Depends on**: Mongoose, Node.js, and other dependencies listed in the `package.json` file.

## Authentication Library
The authentication library used in this project is JSON Web Tokens (JWT), a popular library for generating and verifying JWTs.

* **What it is**: JWT is a library for generating and verifying JSON Web Tokens, which are used for authentication and authorization.
* **Why this project uses it**: The project uses JWT to generate and verify tokens for user authentication and authorization.
* **Where you'll see it**: The `server/middleware/authMiddleware.js` file uses JWT to verify tokens in incoming requests, and the `server/routes/auth.js` file generates JWTs for user authentication.
* **Depends on**: Node.js, Express.js, and other dependencies listed in the `package.json` file.

## Frontend Framework
The frontend framework used in this project is React, a popular JavaScript library for building user interfaces.

* **What it is**: React is a JavaScript library for building user interfaces, allowing developers to create reusable UI components.
* **Why this project uses it**: The project uses React to build the user interface for the application, including the dashboard and other pages.
* **Where you'll see it**: The `src/main.jsx` file renders the React application to the DOM, and the `src/pages/*` files define React components for the application.
* **Depends on**: Node.js, Express.js, and other dependencies listed in the `package.json` file.

## Package Manager
The package manager used in this project is npm, a popular package manager for Node.js.

* **What it is**: npm is a package manager for Node.js that allows developers to install and manage dependencies for their projects.
* **Why this project uses it**: The project uses npm to install and manage dependencies for the project, including Express.js, Mongoose, and other libraries.
* **Where you'll see it**: The `package.json` file lists the dependencies for the project, and the `npm install` command installs the dependencies.
* **Depends on**: Node.js and other dependencies listed in the `package.json` file.

## External APIs
The project uses several external APIs for authentication and authorization, including the `/api/auth/login` and `/api/auth/register` endpoints.

* **What it is**: These endpoints are used for user authentication and registration, and return JWT tokens for authentication.
* **Why this project uses it**: The project uses these endpoints to authenticate and authorize users, and to generate JWT tokens for authentication.
* **Where you'll see it**: The `server/routes/auth.js` file defines the routes for these endpoints, and the `src/pages/Auth.jsx` file uses these endpoints for user authentication and registration.
* **Depends on**: Node.js, Express.js, and other dependencies listed in the `package.json` file.