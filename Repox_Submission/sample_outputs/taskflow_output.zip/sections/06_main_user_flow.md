# Main User Flow

## Step 1 — User Registration
- **What happens**: User provides registration information (name, email, password) and submits the form.
- **File**: `src/pages/Auth.jsx`
- **Evidence**: `const handleSubmit = async (e) => { ... }; const { data } = await axios.post(endpoint, payload);` (axios.post is used to send a POST request to the `/api/auth/register` endpoint)

## Step 2 — Registration Data Validation and User Creation
- **What happens**: The server-side API endpoint (`server/routes/auth.js`) validates the registration data, hashes the password, and creates a new user in the database.
- **File**: `server/routes/auth.js`
- **Evidence**: `router.post('/register', async (req, res) => { ... });` (this function handles the registration request and creates a new user)

## Step 3 — JWT Token Generation and Return
- **What happens**: The server generates a JWT token for the newly created user and returns it in the response.
- **File**: `server/routes/auth.js`
- **Evidence**: `jwt.sign(payload, process.env.JWT_SECRET || 'fallback_secret', { expiresIn: '7d' }, (err, token) => { ... });` (this function generates a JWT token)

## Step 4 — User Login
- **What happens**: The user provides login information (email and password) and submits the form.
- **File**: `src/pages/Auth.jsx`
- **Evidence**: `const handleSubmit = async (e) => { ... }; const { data } = await axios.post(endpoint, payload);` (axios.post is used to send a POST request to the `/api/auth/login` endpoint)

## Step 5 — Login Data Validation and User Authentication
- **What happens**: The server-side API endpoint (`server/routes/auth.js`) validates the login data, checks the password against the stored hash, and verifies the user's existence in the database.
- **File**: `server/routes/auth.js`
- **Evidence**: `router.post('/login', async (req, res) => { ... });` (this function handles the login request and authenticates the user)

## Step 6 — JWT Token Generation and Return (Login)
- **What happens**: The server generates a JWT token for the authenticated user and returns it in the response.
- **File**: `server/routes/auth.js`
- **Evidence**: `jwt.sign(payload, process.env.JWT_SECRET || 'fallback_secret', { expiresIn: '7d' }, (err, token) => { ... });` (this function generates a JWT token)

## Step 7 — User Data Retrieval (GET /me)
- **What happens**: The user sends a GET request to the `/api/auth/me` endpoint to retrieve their user data.
- **File**: `src/pages/Auth.jsx`
- **Evidence**: `const { data } = await axios.get(endpoint);` (axios.get is used to send a GET request to the `/api/auth/me` endpoint)

## Step 8 — Authentication Middleware Verification
- **What happens**: The authentication middleware (`server/middleware/authMiddleware.js`) verifies the JWT token in the request and checks if it's valid and has the correct permissions.
- **File**: `server/middleware/authMiddleware.js`
- **Evidence**: `const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback_secret');` (this function verifies the JWT token)

## Step 9 — User Data Return
- **What happens**: The server returns the user's data in the response.
- **File**: `server/routes/auth.js`
- **Evidence**: `res.json(user);` (this function returns the user's data)

## What We Found
We were able to trace the main user flow through the codebase, including registration, login, and user data retrieval.

## What Remains Unclear
There are some unclear points in the codebase, such as the implementation of the `auth` middleware in `server/routes/tasks.js` and `server/routes/users.js`. Additionally, the `configureMongoDns` function in `server/server.js` is not clear.