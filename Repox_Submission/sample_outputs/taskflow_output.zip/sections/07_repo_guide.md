# Repo Guide

## (root)/
- **Purpose**: Root directory containing essential configuration files and project metadata.
- **File types**: `gitconfig`, `html`, `json`, `javascript`.
- **Capability supported**: Project setup and configuration.
- **Study order**: Read now.

## api/
- **Purpose**: API endpoints and related logic.
- **File types**: `javascript`, `json`.
- **Capability supported**: API functionality.
- **Study order**: Read later.

## public/
- **Purpose**: Publicly accessible files, such as static assets.
- **File types**: Unknown.
- **Capability supported**: Static file hosting.
- **Study order**: Read later.

## server/
- **Purpose**: Server-side logic and configuration.
- **File types**: `json`, `javascript`.
- **Capability supported**: Server functionality.
- **Study order**: Read now.

## src/
- **Purpose**: Source code for the application.
- **File types**: `javascript`, `jsx`, `css`.
- **Capability supported**: Application logic.
- **Study order**: Read now.

### Important Files

- **api/index.js**: Application entry point (score: 180)
- **server/routes/auth.js**: Route definitions file for authentication (score: 170)
- **src/pages/Auth.jsx**: Authentication logic (score: 150)
- **server/middleware/authMiddleware.js**: Authentication logic (score: 145)
- **server/server.js**: Server entry point (score: 100)
- **server/routes/tasks.js**: Route definitions file for tasks (score: 85)
- **server/routes/users.js**: Route definitions file for users (score: 85)
- **src/main.jsx**: LLM / AI agent code (score: 75)
- **tailwind.config.js**: LLM / AI agent code (score: 75)
- **server/models/Task.js**: Data model or schema definition for tasks (score: 70)
- **server/models/User.js**: Data model or schema definition for users (score: 70)
- **.env.example**: Environment variable template (score: 65)