# Product Overview
This is a comprehensive overview of the Indus_Mind project, a cutting-edge platform that leverages AI and machine learning to provide innovative solutions for AEC (Architecture, Engineering, and Construction) project management.

## Who Uses It
The Indus_Mind platform is designed for AEC professionals, project managers, and teams who require efficient and accurate project documentation, collaboration, and knowledge management.

## Core Capabilities
The platform offers the following core capabilities:

- **Project Management**: Create, manage, and track AEC projects, including project planning, scheduling, and resource allocation.
- **Document Management**: Store, organize, and share project documents, including drawings, specifications, and reports.
- **Collaboration**: Enable team members to collaborate on projects, share knowledge, and communicate effectively.
- **AI-Powered Search**: Utilize AI-powered search to quickly find and retrieve relevant project information, including documents, emails, and conversations.
- **Summarization**: Automatically summarize long documents, such as project reports, to provide key insights and recommendations.

## High-Level Data Flow
The Indus_Mind platform processes user input and generates relevant outputs as follows:

- **User Input**: Users provide project information, including project ID, natural language queries, and optional limits for search results.
- **Processing**: The platform uses AI and machine learning algorithms to process user input, search for relevant project information, and generate summaries.
- **Outputs**: The platform provides users with relevant project information, including document chunks, summaries, and search results.

### Technical Architecture
The Indus_Mind platform is built using a microservices architecture, with the following components:

- **Frontend**: Built using Next.js and React, providing a user-friendly interface for users to interact with the platform.
- **Backend**: Built using tRPC, Prisma, and NextAuth.js, providing a scalable and secure backend infrastructure for data storage and processing.
- **AI Services**: Utilize AI and machine learning libraries, including Qdrant, OpenAI, Groq, HuggingFace Transformers, and HuggingFace, to provide AI-powered search and summarization capabilities.
- **Databases**: Utilize Prisma and @prisma/client to provide a robust and scalable database infrastructure for storing project information.

### Key Features
The Indus_Mind platform includes the following key features:

- **User Registration**: Handles user registration by validating input and creating a new user in the database.
- **Authentication**: Handles authentication logic using NextAuth library, providing secure and seamless user authentication.
- **Project Management**: Provides features for creating, managing, and tracking AEC projects.
- **Document Management**: Provides features for storing, organizing, and sharing project documents.
- **Collaboration**: Enables team members to collaborate on projects, share knowledge, and communicate effectively.
- **AI-Powered Search**: Utilizes AI-powered search to quickly find and retrieve relevant project information.
- **Summarization**: Automatically summarizes long documents to provide key insights and recommendations.

### Dockerization
The Indus_Mind platform is containerized using Docker, providing a lightweight and portable infrastructure for deployment.

### Package Managers
The platform uses npm as the package manager for managing dependencies and packages.

### External APIs
The platform interacts with external APIs, including:

- **/api/py/upload**: Handles file uploads for project documents.
- **/api/py/collections/${projectId}**: Handles project collection management.
- **/api/py/query**: Handles AI-powered search and summarization.
- **/api/py/documents/${projectId}/${documentId}**: Handles document vector management.

### Important Files
The following files are crucial to the Indus_Mind platform:

- **src/server/routers/auth.ts**: Handles user registration and authentication.
- **src/app/api/auth/[...nextauth]/route.ts**: Handles authentication logic using NextAuth library.
- **mcp-server/index.ts**: Serves as the entry point for the MCP server, responsible for handling incoming requests and providing tools for searching AEC project documents and summarizing specific documents.
- **src/app/layout.tsx**: Defines the root layout for the Next.js application, providing a basic HTML structure and styling.
- **src/lib/auth.config.ts**: Defines the authentication configuration for the application, including session strategy, max age, and callback functions.
- **src/lib/auth.ts**: Handles authentication logic for the application using NextAuth library.
- **src/server/routers/_app.ts**: Defines the main application router with route definitions for authentication, projects, documents, and chat.
- **src/server/routers/chat.ts**: Defines routes for chat functionality, including listing sessions, getting a session, creating a session, deleting a session, and updating a session title.
- **src/server/routers/document.ts**: Defines routes for document-related operations, including listing documents by project and uploading documents.
- **src/server/routers/project.ts**: Defines routes for project management, including listing, getting, creating, updating, and deleting projects.
- **src/types/next-auth.d.ts**: Defines custom types for Next-Auth authentication logic, including Session and User interfaces.
- **src/app/api/py/collections/[projectId]/route.ts**: Handles DELETE requests to delete a project collection.
- **src/app/api/py/documents/[projectId]/[documentId]/route.ts**: Handles DELETE requests to delete document vectors for a specific project and document.

### Important Summaries
The following summaries are crucial to the Indus_Mind platform:

- **User Registration**: Handles user registration by validating input and creating a new user in the database.
- **Authentication**: Handles authentication logic using NextAuth library, providing secure and seamless user authentication.
- **Project Management**: Provides features for creating, managing, and tracking AEC projects.
- **Document Management**: Provides features for storing, organizing, and sharing project documents.
- **Collaboration**: Enables team members to collaborate on projects, share knowledge, and communicate effectively.
- **AI-Powered Search**: Utilizes AI-powered search to quickly find and retrieve relevant project information.
- **Summarization**: Automatically summarizes long documents to provide key insights and recommendations.