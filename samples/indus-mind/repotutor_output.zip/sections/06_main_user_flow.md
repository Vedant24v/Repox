# Main User Flow

## Step 1 — User Registration
- **What happens**: A new user provides their registration details (name, email, password) to create an account.
- **File**: `src/server/routers/auth.ts`
- **Evidence**: `const user = await ctx.prisma.user.create({ data: { name: input.name, email, hashedPassword }, select: { id: true, email } });`

## Step 2 — Authentication Setup
- **What happens**: The user is redirected to the authentication page, where they can log in or sign up.
- **File**: `src/app/(auth)/layout.tsx`
- **Evidence**: `<div className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden px-4">...`

## Step 3 — User Login
- **What happens**: The user provides their email and password to log in.
- **File**: `src/app/(auth)/login/page.tsx`
- **Evidence**: `import { signIn } from "next-auth/react";`

## Step 4 — Authentication Logic
- **What happens**: The application uses NextAuth to authenticate the user based on the provided credentials.
- **File**: `src/lib/auth.ts`
- **Evidence**: `const user = await prisma.user.findUnique({ where: { email } });`

## Step 5 — Session Creation
- **What happens**: If the user is authenticated successfully, a new session is created.
- **File**: `src/lib/auth.config.ts`
- **Evidence**: `const isLoggedIn = !!auth?.user; const { pathname } = nextUrl;`

## Step 6 — Dashboard Access
- **What happens**: The authenticated user is redirected to the dashboard, where they can access their projects and documents.
- **File**: `src/app/dashboard/layout.tsx`
- **Evidence**: `return (<div className="flex h-screen overflow-hidden bg-background">...`

## Step 7 — Project Management
- **What happens**: The user can manage their projects, including listing, getting, creating, updating, and deleting projects.
- **File**: `src/server/routers/project.ts`
- **Evidence**: `const project = await ctx.prisma.project.findFirst({ where: { id: input.id, userId: ctx.userId } });`

## Step 8 — Document Management
- **What happens**: The user can manage their documents, including listing, getting, creating, updating, and deleting documents.
- **File**: `src/server/routers/document.ts`
- **Evidence**: `const document = await ctx.prisma.document.create({ data: { ... } });`

## Step 9 — Chat Functionality
- **What happens**: The user can access chat functionality, including listing sessions, getting a session, creating a session, deleting a session, and updating a session title.
- **File**: `src/server/routers/chat.ts`
- **Evidence**: `const project = await ctx.prisma.project.findFirst({ where: { id: input.projectId, userId: ctx.userId }, });`

## Step 10 — MCP Server Interaction
- **What happens**: The user can interact with the MCP server to search AEC project documents and summarize specific documents.
- **File**: `mcp-server/index.ts`
- **Evidence**: `const response = await fetch(`${APP_URL}/api/py/query`, { ... });`

## What We Found
We were able to trace the main user flow through the repository, covering user registration, authentication, session creation, dashboard access, project management, document management, chat functionality, and MCP server interaction.

## What Remains Unclear
There are some unclear aspects of the codebase, including the exact implementation of the MCP server interaction and the specifics of the chat functionality. Further investigation would be required to fully understand these components.