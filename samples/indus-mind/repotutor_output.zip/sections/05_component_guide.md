## Component Guide

### Authentication Handler
- **Simple description**: Handles authentication logic for the application using NextAuth library.
- **Technical responsibility**: Authentication logic, user data, and session management.
- **Input**: Email and password credentials.
- **Output**: User data (id, email, name).
- **Connected components**: `src/lib/auth.config.ts`, `src/server/routers/auth.ts`, `src/app/api/auth/[...nextauth]/route.ts`.
- **Key files**: `src/lib/auth.ts`, `src/lib/auth.config.ts`.
- **Confidence**: Confirmed.

### Project Router
- **Simple description**: Defines routes for project management, including listing, getting, creating, updating, and deleting projects.
- **Technical responsibility**: Project data, project routes, and project-related operations.
- **Input**: Project ID, user ID, project name, project description.
- **Output**: Project data, TRPCError.
- **Connected components**: `src/server/routers/_app.ts`, `src/server/routers/project.ts`, `prisma/schema.prisma`.
- **Key files**: `src/server/routers/project.ts`, `prisma/schema.prisma`.
- **Confidence**: Confirmed.

### Document Router
- **Simple description**: Defines routes for document-related operations, including listing documents by project and uploading documents.
- **Technical responsibility**: Document data, document routes, and document-related operations.
- **Input**: Project ID, file name, file data, file size.
- **Output**: List of documents by project, updated document with status and chunk count, deleted document.
- **Connected components**: `src/server/routers/_app.ts`, `src/server/routers/document.ts`, `prisma/schema.prisma`.
- **Key files**: `src/server/routers/document.ts`, `prisma/schema.prisma`.
- **Confidence**: Confirmed.

### Chat Router
- **Simple description**: Defines routes for chat functionality, including listing sessions, getting a session, creating a session, deleting a session, and updating a session title.
- **Technical responsibility**: Chat session data, chat routes, and chat-related operations.
- **Input**: Project ID, session ID, input project ID, input session ID, input title.
- **Output**: List of chat sessions, a chat session, success boolean.
- **Connected components**: `src/server/routers/_app.ts`, `src/server/routers/chat.ts`, `prisma/schema.prisma`.
- **Key files**: `src/server/routers/chat.ts`, `prisma/schema.prisma`.
- **Confidence**: Confirmed.

### MCP Server
- **Simple description**: Serves as the entry point for the MCP server, responsible for handling incoming requests and providing tools for searching AEC project documents and summarizing specific documents.
- **Technical responsibility**: MCP server logic, document searching, and document summarization.
- **Input**: Project ID, natural language query, and optional limit for search results.
- **Output**: Relevant document chunks for a given natural language query or a summary of a specific document.
- **Connected components**: `mcp-server/index.ts`, `src/app/api/py/query/route.ts`, `src/app/api/py/documents/[projectId]/[documentId]/route.ts`.
- **Key files**: `mcp-server/index.ts`, `src/app/api/py/query/route.ts`.
- **Confidence**: Confirmed.

### Root Layout
- **Simple description**: Defines the root layout for the Next.js application, providing a basic HTML structure and styling.
- **Technical responsibility**: Application layout, HTML structure, and styling.
- **Input**: Children (React.ReactNode).
- **Output**: The root layout HTML structure.
- **Connected components**: `src/app/layout.tsx`, `src/app/dashboard/layout.tsx`, `src/app/api/auth/[...nextauth]/route.ts`.
- **Key files**: `src/app/layout.tsx`.
- **Confidence**: Confirmed.

### Authentication Layout
- **Simple description**: Defines the layout structure for authentication pages in the application.
- **Technical responsibility**: Authentication layout, JSX structure.
- **Input**: Children (React.ReactNode).
- **Output**: JSX layout structure.
- **Connected components**: `src/app/(auth)/layout.tsx`, `src/app/dashboard/layout.tsx`, `src/app/api/auth/[...nextauth]/route.ts`.
- **Key files**: `src/app/(auth)/layout.tsx`.
- **Confidence**: Confirmed.

### Dashboard Layout
- **Simple description**: Defines the root layout for the dashboard, rendering a sidebar and a main content area.
- **Technical responsibility**: Dashboard layout, JSX structure.
- **Input**: Children (React.ReactNode).
- **Output**: JSX element representing the dashboard layout.
- **Connected components**: `src/app/dashboard/layout.tsx`, `src/app/layout.tsx`, `src/app/api/auth/[...nextauth]/route.ts`.
- **Key files**: `src/app/dashboard/layout.tsx`.
- **Confidence**: Confirmed.

### Tailwind Configuration
- **Simple description**: Configures Tailwind CSS settings for the project, including dark mode, content sources, and custom theme colors.
- **Technical responsibility**: Tailwind CSS configuration, theme colors.
- **Input**: None.
- **Output**: Tailwind CSS configuration object.
- **Connected components**: `tailwind.config.js`, `src/app/api/auth/[...nextauth]/route.ts`.
- **Key files**: `tailwind.config.js`.
- **Confidence**: Confirmed.

### Prisma Schema
- **Simple description**: Defines the Prisma schema for a PostgreSQL database, including models for users, projects, documents, chat sessions, and messages.
- **Technical responsibility**: Prisma schema, database models.
- **Input**: Environment variables (DATABASE_URL).
- **Output**: Prisma client.
- **Connected components**: `prisma/schema.prisma`, `src/server/routers/project.ts`, `src/server/routers/document.ts`.
- **Key files**: `prisma/schema.prisma`.
- **Confidence**: Confirmed.