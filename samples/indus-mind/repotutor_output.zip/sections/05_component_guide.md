# Component Guide

### Authentication Service
- **Simple description**: Handles user registration and authentication logic.
- **Technical responsibility**: Owns the `/auth` routes and NextAuth configuration.
- **Input**: User registration data, email and password credentials.
- **Output**: Newly created user object, authentication responses.
- **Connected components**: Next.js application, NextAuth library, Prisma database.
- **Key files**: `src/app/api/auth/[...nextauth]/route.ts`, `src/lib/auth.config.ts`, `src/lib/auth.ts`.
- **Confidence**: Confirmed.

### Project Management Service
- **Simple description**: Handles project-related operations, including listing, getting, creating, updating, and deleting projects.
- **Technical responsibility**: Owns the `/project` routes and project data.
- **Input**: Project ID, user ID, project name, description, and optional chat sessions and documents counts.
- **Output**: Project data, including ID, name, description, user ID, documents count, and chat sessions count.
- **Connected components**: Next.js application, Prisma database, Qdrant.
- **Key files**: `src/server/routers/project.ts`, `src/server/routers/_app.ts`.
- **Confidence**: Confirmed.

### Document Management Service
- **Simple description**: Handles document-related operations, including listing documents by project and uploading documents.
- **Technical responsibility**: Owns the `/document` routes and document data.
- **Input**: Project ID, document data, and optional file data.
- **Output**: List of documents, updated document.
- **Connected components**: Next.js application, Prisma database, Rag API service.
- **Key files**: `src/server/routers/document.ts`, `src/server/routers/_app.ts`.
- **Confidence**: Confirmed.

### Chat Management Service
- **Simple description**: Handles chat-related operations, including listing, getting, creating, deleting, and updating chat sessions.
- **Technical responsibility**: Owns the `/chat` routes and chat data.
- **Input**: Project ID, session ID, user ID.
- **Output**: Chat sessions, session, project, messages, success.
- **Connected components**: Next.js application, Prisma database, Rag API service.
- **Key files**: `src/server/routers/chat.ts`, `src/server/routers/_app.ts`.
- **Confidence**: Confirmed.

### MCP Server
- **Simple description**: Serves as the entry point for the MCP server, providing tools for searching AEC project documents and summarizing specific documents within a project.
- **Technical responsibility**: Owns the MCP server logic and API calls.
- **Input**: Project ID, natural language query, and optional limit for search results.
- **Output**: Relevant document chunks for a given query, or a summary of a specific document.
- **Connected components**: Next.js application, IndusMind service via API calls, MCP Server SDK.
- **Key files**: `mcp-server/index.ts`.
- **Confidence**: Confirmed.

### Next.js Application Layout
- **Simple description**: Defines the root layout for the Next.js application, providing a basic HTML structure and styling.
- **Technical responsibility**: Owns the application layout and styling.
- **Input**: Children React components.
- **Output**: Styled HTML document with the application content.
- **Connected components**: Next.js application, React, CSS.
- **Key files**: `src/app/layout.tsx`.
- **Confidence**: Confirmed.

### Authentication Page Layout
- **Simple description**: Defines the layout for the authentication page in the Next.js application, including branding and background elements.
- **Technical responsibility**: Owns the authentication page layout.
- **Input**: Children React components.
- **Output**: JSX element representing the authentication page layout.
- **Connected components**: Next.js application, React, CSS.
- **Key files**: `src/app/(auth)/layout.tsx`.
- **Confidence**: Confirmed.

### Dashboard Layout
- **Simple description**: Defines the root layout for the dashboard in a Next.js application, responsible for rendering the sidebar and main content area.
- **Technical responsibility**: Owns the dashboard layout.
- **Input**: Children React components.
- **Output**: JSX element representing the dashboard layout.
- **Connected components**: Next.js application, React, CSS.
- **Key files**: `src/app/dashboard/layout.tsx`.
- **Confidence**: Confirmed.