# Tech Stack

## Backend Runtime

We use Node.js as our backend runtime, which is the foundation for our server-side application. Node.js provides an event-driven, non-blocking I/O model that makes it ideal for real-time web applications.

* **What it is**: Node.js is a JavaScript runtime built on Chrome's V8 JavaScript engine.
* **Why this project uses it**: We chose Node.js for its performance, scalability, and ease of use. It allows us to write server-side logic in JavaScript, which is consistent with our frontend codebase.
* **Where you'll see it**: `mcp-server/index.ts`, `src/server/routers/auth.ts`, `src/server/routers/_app.ts`, and other server-side files.
* **Depends on**: `npm`, `docker`, and various Node.js packages such as `@prisma/client`, `next-auth`, and `trpc`.

## Database

We use Prisma as our database management system, which provides a high-level, type-safe interface for interacting with our database.

* **What it is**: Prisma is a modern database toolkit that allows you to define your database schema using a high-level, type-safe API.
* **Why this project uses it**: We chose Prisma for its ease of use, performance, and scalability. It provides a simple and intuitive way to interact with our database, and its type safety features help prevent errors.
* **Where you'll see it**: `src/server/routers/auth.ts`, `src/lib/auth.ts`, and other files that interact with the database.
* **Depends on**: `@prisma/client`, `prisma`, and various other packages such as `bcryptjs` and `next-auth`.

## Authentication Library

We use NextAuth.js as our authentication library, which provides a simple and secure way to handle user authentication.

* **What it is**: NextAuth.js is a popular authentication library for Next.js applications.
* **Why this project uses it**: We chose NextAuth.js for its ease of use, security, and flexibility. It provides a simple way to handle user authentication, and its customizable features allow us to tailor it to our specific needs.
* **Where you'll see it**: `src/app/api/auth/[...nextauth]/route.ts`, `src/lib/auth.config.ts`, and other files that interact with NextAuth.js.
* **Depends on**: `next-auth`, `bcryptjs`, and various other packages such as `prisma` and `next`.

## Frontend Framework

We use Next.js as our frontend framework, which provides a simple and efficient way to build server-side rendered (SSR) and statically generated websites.

* **What it is**: Next.js is a popular React-based framework for building server-side rendered and statically generated websites.
* **Why this project uses it**: We chose Next.js for its ease of use, performance, and scalability. It provides a simple way to build SSR and statically generated websites, and its customizable features allow us to tailor it to our specific needs.
* **Where you'll see it**: `src/app/layout.tsx`, `src/app/dashboard/layout.tsx`, and other files that interact with Next.js.
* **Depends on**: `next`, `react`, and various other packages such as `next-auth` and `prisma`.

## AI/LLM Libraries

We use various AI/LLM libraries to provide advanced features such as natural language processing and text summarization.

* **What it is**: Qdrant, OpenAI, Groq, HuggingFace Transformers, and HuggingFace are popular AI/LLM libraries used for natural language processing and text summarization.
* **Why this project uses it**: We chose these libraries for their ease of use, performance, and scalability. They provide advanced features such as natural language processing and text summarization, which are essential for our application.
* **Where you'll see it**: `mcp-server/index.ts` and other files that interact with these libraries.
* **Depends on**: `qdrant`, `openai`, `groq`, `huggingface-transformers`, and `huggingface`.

## Docker

We use Docker as our containerization platform, which provides a simple and efficient way to package and deploy our application.

* **What it is**: Docker is a popular containerization platform that allows you to package and deploy applications in containers.
* **Why this project uses it**: We chose Docker for its ease of use, performance, and scalability. It provides a simple way to package and deploy our application, and its customizable features allow us to tailor it to our specific needs.
* **Where you'll see it**: `mcp-server/index.ts` and other files that interact with Docker.
* **Depends on**: `docker`, `npm`, and various other packages such as `next` and `prisma`.

## Package Manager

We use npm as our package manager, which provides a simple and efficient way to manage dependencies and packages.

* **What it is**: npm is a popular package manager for Node.js applications.
* **Why this project uses it**: We chose npm for its ease of use, performance, and scalability. It provides a simple way to manage dependencies and packages, and its customizable features allow us to tailor it to our specific needs.
* **Where you'll see it**: `package.json` and other files that interact with npm.
* **Depends on**: `npm`, `docker`, and various other packages such as `next` and `prisma`.