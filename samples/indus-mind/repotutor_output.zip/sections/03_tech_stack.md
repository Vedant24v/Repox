# Tech Stack

## Backend Runtime
We use Node.js as our backend runtime, which allows us to run JavaScript on the server-side. This is evident in the `mcp-server/index.ts` file, where we use the `fetch` API to make API calls to the IndusMind service.

* **What it is**: Node.js is a JavaScript runtime built on Chrome's V8 JavaScript engine.
* **Why this project uses it**: We use Node.js to run our backend server and handle API requests.
* **Where you'll see it**: `mcp-server/index.ts`, `src/server/routers/auth.ts`, `src/server/routers/_app.ts`
* **Depends on**: `npm`, `docker`

## Database
We use Prisma as our database ORM, which allows us to interact with our database using a high-level API. This is evident in the `src/server/routers/auth.ts` file, where we use the `ctx.prisma.user.create` method to create a new user.

* **What it is**: Prisma is a database ORM that allows us to interact with our database using a high-level API.
* **Why this project uses it**: We use Prisma to interact with our database and perform CRUD operations.
* **Where you'll see it**: `src/server/routers/auth.ts`, `src/lib/auth.ts`
* **Depends on**: `@prisma/client`

## Authentication Library
We use NextAuth.js as our authentication library, which allows us to handle authentication logic for our Next.js application. This is evident in the `src/app/api/auth/[...nextauth]/route.ts` file, where we import the `handlers` function from `@/lib/auth`.

* **What it is**: NextAuth.js is an authentication library that allows us to handle authentication logic for our Next.js application.
* **Why this project uses it**: We use NextAuth.js to handle authentication logic and provide routes for authentication operations.
* **Where you'll see it**: `src/app/api/auth/[...nextauth]/route.ts`, `src/lib/auth.ts`
* **Depends on**: `next-auth`

## Frontend Framework
We use Next.js as our frontend framework, which allows us to build server-side rendered (SSR) and statically generated websites. This is evident in the `src/app/layout.tsx` file, where we define the root layout for our Next.js application.

* **What it is**: Next.js is a frontend framework that allows us to build SSR and statically generated websites.
* **Why this project uses it**: We use Next.js to build our frontend application and provide a basic HTML structure and styling.
* **Where you'll see it**: `src/app/layout.tsx`, `src/app/dashboard/layout.tsx`, `src/app/api/auth/[...nextauth]/route.ts`
* **Depends on**: `next/font/google`, `next/providers/providers`, `app/globals.css`

## AI/LLM Libraries
We use Qdrant, OpenAI, Groq, HuggingFace Transformers, and HuggingFace as our AI/LLM libraries, which allow us to integrate AI and machine learning capabilities into our application. This is evident in the `mcp-server/index.ts` file, where we use the `fetch` API to make API calls to the IndusMind service.

* **What it is**: Qdrant, OpenAI, Groq, HuggingFace Transformers, and HuggingFace are AI/LLM libraries that allow us to integrate AI and machine learning capabilities into our application.
* **Why this project uses it**: We use these libraries to integrate AI and machine learning capabilities into our application and provide features such as document summarization and search.
* **Where you'll see it**: `mcp-server/index.ts`
* **Depends on**: `npm`, `docker`

## Docker
We use Docker as our containerization platform, which allows us to package our application and its dependencies into a single container. This is evident in the `mcp-server/index.ts` file, where we use the `fetch` API to make API calls to the IndusMind service.

* **What it is**: Docker is a containerization platform that allows us to package our application and its dependencies into a single container.
* **Why this project uses it**: We use Docker to containerize our application and its dependencies.
* **Where you'll see it**: `mcp-server/index.ts`
* **Depends on**: `npm`

## Package Manager
We use npm as our package manager, which allows us to manage our dependencies and install packages. This is evident in the `mcp-server/index.ts` file, where we use the `fetch` API to make API calls to the IndusMind service.

* **What it is**: npm is a package manager that allows us to manage our dependencies and install packages.
* **Why this project uses it**: We use npm to manage our dependencies and install packages.
* **Where you'll see it**: `mcp-server/index.ts`
* **Depends on**: `docker`