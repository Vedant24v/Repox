# How to Run
=====================================

## Prerequisites
----------------

* Node.js 20 (or later)
* Docker (for containerized setup)

## Environment Setup
--------------------

* Set the following environment variables:
  + `NEXT_TELEMETRY_DISABLED`
  + `NODE_ENV`

## Install Dependencies
-----------------------

```bash
npm ci
```

## Run the Development Server
------------------------------

```bash
npm run dev
```

## Run Tests
-------------

> ⚠️ The repository does not provide enough information to confirm this step.

## Build for Production
------------------------

```bash
npm run build
```

## Run the Production Server
-----------------------------

```bash
npm run start
```

## Docker / Container Setup
---------------------------

To set up the containerized environment, run the following command:

```bash
docker-compose up
```

This will start the Next.js and PostgreSQL containers in detached mode. You can then access the application at `http://localhost:3000`.