# How to Run
=====================================

## Prerequisites
----------------

* Node.js (version 20 or higher)
* Docker (version 20 or higher)
* Docker Compose (version 2 or higher)

## Environment Setup
---------------------

* Set the following environment variables:
  + `NEXT_PUBLIC_QDRANT_API_KEY`
  + `NEXT_PUBLIC_GROQ_API_KEY`
  + `NEXT_PUBLIC_MCP_API_KEY`

## Install Dependencies
------------------------

```bash
npm ci
```

## Run the Development Server
------------------------------

```bash
npm run dev
```

## Run Tests
-------------

> ⚠️ The repository does not provide enough information to confirm this step.

## Build for Production
------------------------

```bash
npm run build
```

## Run the Production Server
-----------------------------

```bash
npm start
```

## Docker / Container Setup
---------------------------

To spin up the Next.js and PostgreSQL containers, run the following command:

```bash
docker-compose up --build
```

This will start the containers in detached mode. You can access the Next.js app at `http://localhost:3000` and the PostgreSQL database at `http://localhost:5432`.

Note: Make sure to update the environment variables in the `docker-compose.yml` file to match your local environment.