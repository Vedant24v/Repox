# Repo Guide
## Top-Level Directory Summary

### Root Directory
- **Purpose**: Project configuration and setup
- **File types**: Git Config, YAML, Dockerfile, TypeScript
- **Capability supported**: Project initialization and setup
- **Study order**: Read now

### mcp-server Directory
- **Purpose**: Server-side application entry point
- **File types**: TypeScript, JSON
- **Capability supported**: Server-side application entry point and configuration
- **Study order**: Read now

### prisma Directory
- **Purpose**: Database schema and migration management
- **File types**: Unknown
- **Capability supported**: Database schema management and migration
- **Study order**: Read later

### public Directory
- **Purpose**: Publicly accessible static assets
- **File types**: Unknown
- **Capability supported**: Publicly accessible static assets
- **Study order**: Read later

### src Directory
- **Purpose**: Frontend application code
- **File types**: TypeScript, CSS, TypeScript (JSX), Unknown, JavaScript (JSX)
- **Capability supported**: Frontend application logic and rendering
- **Study order**: Read now

## Heuristically Important Files

### Authentication and Authorization

* `src/server/routers/auth.ts` — Route definitions file
* `src/app/api/auth/[...nextauth]/route.ts` — Authentication logic
* `src/lib/auth.config.ts` — Authentication logic
* `src/lib/auth.ts` — Authentication logic

### Server-Side Application Entry Point

* `mcp-server/index.ts` — Application entry point

### Next.js Framework Layouts

* `src/app/(auth)/layout.tsx` — Next.js / framework layout root
* `src/app/dashboard/layout.tsx` — Next.js / framework layout root
* `src/app/layout.tsx` — Next.js / framework layout root

### Route Definitions

* `src/server/routers/_app.ts` — Route definitions file
* `src/server/routers/chat.ts` — Route definitions file
* `src/server/routers/document.ts` — Route definitions file
* `src/server/routers/project.ts` — Route definitions file

### Miscellaneous

* `src/server/routers/chat.ts` — Route definitions file
* `src/server/routers/document.ts` — Route definitions file
* `src/server/routers/project.ts` — Route definitions file