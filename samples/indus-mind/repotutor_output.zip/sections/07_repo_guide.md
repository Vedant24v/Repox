# Repo Guide
## Top-Level Directory Summary

### (root)/
- **Purpose**: Project configuration and setup
- **File types**: Git Config, YAML, Dockerfile, TypeScript
- **Capability supported**: Project initialization and setup
- **Study order**: Read now

### mcp-server/
- **Purpose**: Microservices server implementation
- **File types**: TypeScript, JSON
- **Capability supported**: Microservices server functionality
- **Study order**: Read later

### prisma/
- **Purpose**: Prisma schema and configuration
- **File types**: Prisma schema
- **Capability supported**: Database schema management
- **Study order**: Read later

### public/
- **Purpose**: Publicly accessible files
- **File types**: Unknown
- **Capability supported**: Public file hosting
- **Study order**: Read later

### src/
- **Purpose**: Application source code
- **File types**: TypeScript, CSS, TypeScript (JSX), Unknown, JavaScript (JSX)
- **Capability supported**: Application logic and functionality
- **Study order**: Read now

## Heuristically Important Files

### Essential Files

- `src/server/routers/auth.ts` — Route definitions file for authentication
- `src/app/api/auth/[...nextauth]/route.ts` — Authentication logic implementation
- `mcp-server/index.ts` — Application entry point for microservices server
- `src/app/(auth)/layout.tsx` — Next.js layout root for authentication
- `src/app/dashboard/layout.tsx` — Next.js layout root for dashboard
- `src/app/layout.tsx` — Next.js layout root for application
- `src/lib/auth.config.ts` — Authentication configuration file
- `src/lib/auth.ts` — Authentication logic implementation
- `src/server/routers/_app.ts` — Route definitions file for application
- `src/server/routers/chat.ts` — Route definitions file for chat functionality
- `src/server/routers/document.ts` — Route definitions file for document functionality
- `src/server/routers/project.ts` — Route definitions file for project functionality
- `src/types/next-auth.d.ts` — Type definitions for NextAuth

### Secondary Files

- `src/app/api/py/collections/[projectId]/route.ts` — API handler or route file for project collections
- `src/app/api/py/documents/[projectId]/[documentId]/route.ts` — API handler or route file for project documents
- `src/app/api/py/query/route.ts` — API handler or route file for query functionality
- `src/app/api/py/upload/route.ts` — API handler or route file for upload functionality
- `src/app/api/trpc/[trpc]/route.ts` — API handler or route file for TRPC functionality
- `tailwind.config.js` — Configuration file for Tailwind CSS
- `prisma/schema.prisma` — Prisma schema file for database management