# Repo Guide

## (root)/
- **Purpose**: Configuration and setup of the project
- **File types**: Git Config, HTML, JSON, JavaScript
- **Capability supported**: Project initialization, configuration, and setup
- **Study order**: Read now

## api/
- **Purpose**: API endpoints and data exchange
- **File types**: JavaScript, JSON
- **Capability supported**: API routing and data exchange
- **Study order**: Read now

## public/
- **Purpose**: Static files and assets accessible by the web server
- **File types**: Unknown
- **Capability supported**: Static file serving
- **Study order**: Read later

## server/
- **Purpose**: Server-side logic and API handling
- **File types**: Unknown, JSON, JavaScript
- **Capability supported**: Server-side routing, API handling, and data processing
- **Study order**: Read now

## src/
- **Purpose**: Frontend application code and UI components
- **File types**: JavaScript (JSX), CSS, JavaScript
- **Capability supported**: Frontend application logic, UI components, and styling
- **Study order**: Read now

### Heuristically Important Files

- `api/index.js`: Application entry point (score: 180)
- `server/routes/auth.js`: Route definitions file for authentication (score: 170)
- `src/pages/Auth.jsx`: Authentication logic and UI component (score: 150)
- `server/middleware/authMiddleware.js`: Authentication logic and middleware (score: 145)
- `server/server.js`: Server application entry point (score: 100)
- `server/routes/tasks.js`: Route definitions file for tasks (score: 85)
- `server/routes/users.js`: Route definitions file for users (score: 85)
- `src/main.jsx`: LLM / AI agent code and application entry point (score: 75)
- `tailwind.config.js`: LLM / AI agent code and styling configuration (score: 75)
- `server/models/Task.js`: Data model or schema definition for tasks (score: 70)
- `server/models/User.js`: Data model or schema definition for users (score: 70)
- `.env.example`: Environment variable template (score: 65)
- `server/.env.example`: Environment variable template (score: 65)
- `src/pages/Dashboard.jsx`: Frontend page component for dashboard (score: 65)
- `src/components/Avatar.jsx`: Shared UI component for avatar (score: 60)
- `src/components/Header.jsx`: Shared UI component for header (score: 60)
- `src/components/KanbanBoard.jsx`: Shared UI component for kanban board (score: 60)
- `src/components/KanbanColumn.jsx`: Shared UI component for kanban column (score: 60)
- `src/components/TaskCard.jsx`: Shared UI component for task card (score: 60)
- `src/components/TaskModal.jsx`: Shared UI component for task modal (score: 60)