## Component Guide

### API Server
- **Simple description**: Exports the Vercel serverless application entry point.
- **Technical responsibility**: Manages the Vercel serverless application entry point.
- **Input**: None
- **Output**: The Vercel serverless application entry point.
- **Connected components**: ../server/server
- **Key files**: api/index.js
- **Confidence**: Confirmed

### Authentication Routes
- **Simple description**: Handles user registration, login, and authentication routes for the application.
- **Technical responsibility**: Manages user registration, login, and authentication routes.
- **Input**: User registration and login data, including email, password, and name.
- **Output**: JSON Web Tokens (JWT) and user data.
- **Connected components**: express, User model, bcrypt, jwt
- **Key files**: server/routes/auth.js
- **Confidence**: Confirmed

### Authentication Logic
- **Simple description**: Handles authentication logic for user login and registration, interacting with API endpoints and storing user data in local storage.
- **Technical responsibility**: Manages user authentication logic.
- **Input**: User input data (name, email, password), API endpoint URLs, and user authentication status.
- **Output**: User authentication token, user data, and navigation to the dashboard.
- **Connected components**: API endpoints (/api/auth/login, /api/auth/register), Local storage (localStorage), React Router (useNavigate)
- **Key files**: src/pages/Auth.jsx
- **Confidence**: Confirmed

### Authentication Middleware
- **Simple description**: Handles authentication logic for incoming requests, verifying JWT tokens and setting the user on the request object.
- **Technical responsibility**: Manages authentication logic for incoming requests.
- **Input**: HTTP request object (req), HTTP response object (res), and the next middleware function in the chain (next)
- **Output**: HTTP response object (res) with a JSON body indicating authentication success or failure
- **Connected components**: jsonwebtoken, process.env.JWT_SECRET
- **Key files**: server/middleware/authMiddleware.js
- **Confidence**: Confirmed

### Server Setup
- **Simple description**: Manages the Express.js server, handles database connections, and sets up routes for authentication, tasks, and users.
- **Technical responsibility**: Manages the Express.js server and database connections.
- **Input**: Environment variables (e.g., MONGO_URI, MONGO_DNS_SERVERS, PORT), request data, and events.
- **Output**: JSON responses, database connections, and server logs.
- **Connected components**: MongoDB, Vercel (for production), Local dev environment
- **Key files**: server/server.js
- **Confidence**: Confirmed

### Task CRUD Operations
- **Simple description**: Handles CRUD operations for tasks, including retrieving, creating, updating, and deleting tasks.
- **Technical responsibility**: Manages task CRUD operations.
- **Input**: HTTP requests (GET, POST, PUT, DELETE) with task data, user authentication
- **Output**: JSON responses with tasks or error messages
- **Connected components**: express, Task model, authMiddleware
- **Key files**: server/routes/tasks.js
- **Confidence**: Confirmed

### User Route Definitions
- **Simple description**: Handles user route definitions, including getting, creating, and deleting users, with authentication and authorization checks.
- **Technical responsibility**: Manages user route definitions.
- **Input**: User ID, user data (name, email, password, role), API requests
- **Output**: User data, error messages, server errors
- **Connected components**: User model, Task model, authMiddleware
- **Key files**: server/routes/users.js
- **Confidence**: Confirmed

### React Application Rendering
- **Simple description**: Renders the React application to the DOM.
- **Technical responsibility**: Manages React application rendering.
- **Input**: HTML element with id 'root'
- **Output**: Rendered React application
- **Connected components**: ./App.jsx, ./index.css
- **Key files**: src/main.jsx
- **Confidence**: Confirmed

### Tailwind CSS Configuration
- **Simple description**: Configures Tailwind CSS settings, including content, theme, and plugins.
- **Technical responsibility**: Manages Tailwind CSS configuration.
- **Input**: None
- **Output**: Tailwind CSS configuration object
- **Connected components**: none
- **Key files**: tailwind.config.js
- **Confidence**: Confirmed

### Task Model
- **Simple description**: Defines the data model for tasks in the application, including properties such as title, description, status, and assignee.
- **Technical responsibility**: Manages task data model.
- **Input**: None
- **Output**: A Mongoose model for tasks
- **Connected components**: User
- **Key files**: server/models/Task.js
- **Confidence**: Confirmed

### User Model
- **Simple description**: Defines the User model schema using Mongoose, including data validation and automatic generation of initials.
- **Technical responsibility**: Manages user data model.
- **Input**: User data to be saved, including name, email, password, role, color, and ownerId.
- **Output**: A User model instance, with automatically generated initials if name is provided.
- **Connected components**: mongoose
- **Key files**: server/models/User.js
- **Confidence**: Confirmed

### Environment Variable Templates
- **Simple description**: Provides templates for environment variables, specifically the VITE_API_URL for frontend API endpoint and backend configuration environment variables.
- **Technical responsibility**: Manages environment variable templates.
- **Input**: None
- **Output**: Environment variable templates
- **Connected components**: Backend API, MongoDB, Node.js
- **Key files**: .env.example, server/.env.example
- **Confidence**: Confirmed

### Dashboard Page
- **Simple description**: Renders the dashboard page with a Kanban board and task modal.
- **Technical responsibility**: Manages dashboard page rendering.
- **Input**: handleLogout function
- **Output**: Dashboard page UI
- **Connected components**: ../components/Header, ../components/KanbanBoard, ../components/TaskModal, ../context/TaskContext
- **Key files**: src/pages/Dashboard.jsx
- **Confidence**: Confirmed

### Avatar Component
- **Simple description**: Renders a user's avatar with optional name and role display.
- **Technical responsibility**: Manages avatar rendering.
- **Input**: ['userObj', 'userId', 'size', 'showName', 'showRole']
- **Output**: ['Avatar component']
- **Connected components**: ../context/TaskContext
- **Key files**: src/components/Avatar.jsx
- **Confidence**: Confirmed

### Header Component
- **Simple description**: The Header component is responsible for rendering the top navigation bar of the application, displaying task statistics, and providing a search input field.
- **Technical responsibility**: Manages header rendering.
- **Input**: handleLogout, filter, setFilter, openModal
- **Output**: none
- **Connected components**: ../context/TaskContext, ./TeamModal
- **Key files**: src/components/Header.jsx
- **Confidence**: Confirmed

### Kanban Board Component
- **Simple description**: Renders a Kanban board with draggable task cards and columns, handling task movement and reordering.
- **Technical responsibility**: Manages Kanban board rendering.
- **Input**: filteredTasks, tasks, moveTask, reorderTasks, loading
- **Output**: Draggable task cards and columns, with task movement and reordering functionality
- **Connected components**: TaskContext, KanbanColumn, TaskCard
- **Key files**: src/components/KanbanBoard.jsx
- **Confidence**: Confirmed

### Kanban Column Component
- **Simple description**: Renders a Kanban column component with a list of tasks and allows users to add new tasks.
- **Technical responsibility**: Manages Kanban column rendering.
- **Input**: column, tasks
- **Output**: renders a UI component
- **Connected components**: @dnd-kit/core, @dnd-kit/sortable, lucide-react, ../context/TaskContext
- **Key files**: src/components/KanbanColumn.jsx
- **Confidence**: Confirmed

### Task Card Component
- **Simple description**: Renders a task card component with drag-and-drop functionality and action buttons.
- **Technical responsibility**: Manages task card rendering.
- **Input**: task object
- **Output**: renders JSX component
- **Connected components**: @dnd-kit/sortable, @dnd-kit/utilities, lucide-react, Avatar
- **Key files**: src/components/TaskCard.jsx
- **Confidence**: Confirmed

### Task Modal Component
- **Simple description**: This file is responsible for rendering a modal UI component for creating, editing, or viewing tasks. It handles form validation and submission to create or update tasks.
- **Technical responsibility**: Manages task modal rendering.
- **Input**: activeModal, users, createTask, updateTask, closeModal
- **Output**: createTask, updateTask, closeModal
- **Connected components**: ../context/TaskContext, ../data/mockData, ./Avatar
- **Key files**: src/components/TaskModal.jsx
- **Confidence**: Confirmed