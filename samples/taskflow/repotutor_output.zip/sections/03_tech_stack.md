# Tech Stack

## Backend Runtime
### Node.js
* **What it is**: A JavaScript runtime environment that allows developers to run JavaScript on the server-side.
* **Why this project uses it**: The project uses Node.js as its backend runtime, allowing for efficient and scalable server-side logic. (See `server/server.js`)
* **Where you'll see it**: `server/server.js`, `server/routes/auth.js`, `server/middleware/authMiddleware.js`
* **Depends on**: Express.js, Mongoose, bcrypt, jsonwebtoken

### Express.js
* **What it is**: A popular Node.js web framework for building web applications and APIs.
* **Why this project uses it**: Express.js is used as the web framework for the project, providing a robust and flexible way to handle HTTP requests and responses. (See `server/server.js`)
* **Where you'll see it**: `server/server.js`, `server/routes/auth.js`, `server/routes/tasks.js`, `server/routes/users.js`
* **Depends on**: Node.js, Mongoose, bcrypt, jsonwebtoken

## Database
### MongoDB
* **What it is**: A NoSQL database that stores data in a JSON-like format.
* **Why this project uses it**: MongoDB is used as the project's database, providing a flexible and scalable way to store and retrieve data. (See `server/server.js`)
* **Where you'll see it**: `server/server.js`, `server/models/Task.js`
* **Depends on**: Mongoose

### Mongoose
* **What it is**: A MongoDB object modeling tool for Node.js, providing a way to interact with MongoDB using JavaScript.
* **Why this project uses it**: Mongoose is used to define and interact with the project's MongoDB database, providing a simple and intuitive way to work with data. (See `server/models/Task.js`)
* **Where you'll see it**: `server/models/Task.js`, `server/server.js`
* **Depends on**: MongoDB

## Authentication and Authorization
### JWT (JSON Web Tokens)
* **What it is**: A lightweight, web token-based authentication standard.
* **Why this project uses it**: JWT is used to authenticate and authorize users, providing a secure and efficient way to verify user identities. (See `server/middleware/authMiddleware.js`)
* **Where you'll see it**: `server/middleware/authMiddleware.js`, `server/routes/auth.js`
* **Depends on**: Node.js, Express.js

### bcrypt
* **What it is**: A password hashing library for Node.js.
* **Why this project uses it**: bcrypt is used to hash and verify user passwords, providing a secure way to store and compare passwords. (See `server/routes/auth.js`)
* **Where you'll see it**: `server/routes/auth.js`
* **Depends on**: Node.js, Express.js

## Frontend Framework
### React
* **What it is**: A JavaScript library for building user interfaces.
* **Why this project uses it**: React is used to build the project's frontend, providing a flexible and efficient way to create and update user interfaces. (See `src/main.jsx`)
* **Where you'll see it**: `src/main.jsx`, `src/pages/Auth.jsx`
* **Depends on**: Node.js, ReactDOM

## Package Manager
### npm (Node Package Manager)
* **What it is**: A package manager for Node.js, allowing developers to easily install and manage dependencies.
* **Why this project uses it**: npm is used to manage the project's dependencies, providing a simple and efficient way to install and update packages. (See `package.json`)
* **Where you'll see it**: `package.json`
* **Depends on**: Node.js

## External APIs
### /api/auth/me
* **What it is**: An API endpoint for retrieving user authentication information.
* **Why this project uses it**: The `/api/auth/me` endpoint is used to retrieve user authentication information, providing a way to verify user identities. (See `server/routes/auth.js`)
* **Where you'll see it**: `server/routes/auth.js`
* **Depends on**: Node.js, Express.js, JWT

### /api/users
* **What it is**: An API endpoint for managing user data.
* **Why this project uses it**: The `/api/users` endpoint is used to manage user data, providing a way to create, read, update, and delete user information. (See `server/routes/users.js`)
* **Where you'll see it**: `server/routes/users.js`
* **Depends on**: Node.js, Express.js, Mongoose

### /api/tasks
* **What it is**: An API endpoint for managing task data.
* **Why this project uses it**: The `/api/tasks` endpoint is used to manage task data, providing a way to create, read, update, and delete task information. (See `server/routes/tasks.js`)
* **Where you'll see it**: `server/routes/tasks.js`
* **Depends on**: Node.js, Express.js, Mongoose

## CSS Framework
### Tailwind CSS
* **What it is**: A utility-first CSS framework for building custom user interfaces.
* **Why this project uses it**: Tailwind CSS is used to style the project's frontend, providing a flexible and efficient way to create custom UI components. (See `tailwind.config.js`)
* **Where you'll see it**: `tailwind.config.js`
* **Depends on**: Node.js, React