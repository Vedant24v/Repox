# Main User Flow

## Step 1 — User Registration
- **What happens**: User submits registration form with name, email, and password.
- **File**: `src/pages/Auth.jsx`
- **Evidence**: `const handleSubmit = async (e) => {   e.preventDefault()   setError('')    const endpoint = isLogin ? '/api/auth/login' : '/api/auth/register';`

## Step 2 — API Call to Register
- **What happens**: The frontend sends a POST request to the `/api/auth/register` endpoint with user data.
- **File**: `server/routes/auth.js`
- **Evidence**: `router.post('/register', async (req, res) => { ... });`

## Step 3 — User Creation and JWT Generation
- **What happens**: The `/api/auth/register` endpoint creates a new user in the database and generates a JSON Web Token (JWT) for authentication.
- **File**: `server/routes/auth.js`
- **Evidence**: `const user = new User({ name, email, password }); const salt = await bcrypt.genSalt(10); user.password = await bcrypt.hash(password, salt); const token = [REDACTED] user: user._id }, process.env.JWT_SECRET || 'fallback_secret');`

## Step 4 — JWT Verification and User Data Retrieval
- **What happens**: The frontend receives the JWT and verifies it using the `authMiddleware` function. If valid, the middleware retrieves the user data from the database.
- **File**: `server/middleware/authMiddleware.js`
- **Evidence**: `const decoded = jwt.verify(token, process.env.JWT_SECRET || 'fallback_secret'); req.user = decoded.user; next();`

## Step 5 — User Data Storage in Local Storage
- **What happens**: The frontend stores the user data in local storage for future use.
- **File**: `src/pages/Auth.jsx`
- **Evidence**: `localStorage.setItem('token', token); localStorage.setItem('user', JSON.stringify(user));`

## Step 6 — Redirect to Dashboard
- **What happens**: The frontend redirects the user to the dashboard page.
- **File**: `src/pages/Auth.jsx`
- **Evidence**: `useNavigate().push('/dashboard');`

## Step 7 — Dashboard Page Rendering
- **What happens**: The dashboard page is rendered with the user's data and tasks.
- **File**: `src/pages/Dashboard.jsx`
- **Evidence**: `export default function Dashboard({ handleLogout }) { ... }`

## Step 8 — Task Management and Updates
- **What happens**: The user can create, update, and delete tasks on the dashboard page.
- **File**: `server/routes/tasks.js`
- **Evidence**: `router.get('/', auth, async (req, res) => { ... }); router.post('/', auth, async (req, res) => { ... }); router.put('/:id', auth, async (req, res) => { ... }); router.delete('/:id', auth, async (req, res) => { ... });`

## What We Found
We were able to trace the main user flow through the repository, from user registration to task management on the dashboard page.

## What Remains Unclear
There are some unclear points in the codebase, such as the implementation of the `authMiddleware` function and the `Task` model. Additionally, the `src/main.jsx` file is not explicitly connected to any other file, and its purpose is unclear.