# How to Run

## Prerequisites
- Node.js 18+
- A MongoDB Atlas connection string (or local MongoDB)

## Environment Setup
- `VITE_API_URL`
- `MONGO_URI`
- `JWT_SECRET`
- `PORT`

## Install Dependencies
```bash
npm install
```

## Run the Development Server
Open **two terminals**:

```bash
# Terminal 1 — Backend
node server/server.js

# Terminal 2 — Frontend
node node_modules/vite/bin/vite.js
```

Visit `http://localhost:5173`

## Run Tests
> ⚠️ The repository does not provide enough information to confirm this step.

## Build for Production
```bash
vite build
```

## Docker / Container Setup
> ⚠️ The repository does not provide enough information to confirm this step.